class AppConfigurations {
  static const String ApplicationName = 'Government';
}
