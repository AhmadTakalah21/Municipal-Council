class RoutePaths {

  static const Home = '/Home';
  static const News = '/NewsScreen';
  static const DecisionScreen = '/DecisionScreen';
  static const EventsScreen = '/EventsScreen';
  static const ServicesScreen = '/ServicesScreen';
  static const AboutScreen = '/AboutScreen';
  static const ReportScreen = '/ReportScreen';
  static const SplashScreen = '/SplashScreen';
}
