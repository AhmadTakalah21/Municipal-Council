class Service {
  final String mainImage;
  final List<String> required_papers;
  final String category;

  const Service(
      {required this.mainImage,
      required this.required_papers,
      required this.category});
}
